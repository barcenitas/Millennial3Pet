from django.apps import AppConfig


class MillenialpetConfig(AppConfig):
    name = 'MillenialPet'
