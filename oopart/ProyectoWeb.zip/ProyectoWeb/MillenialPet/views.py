from django.shortcuts import render
from django.contrib import messages, sessions
#------------------------Para el login
from django import forms
from django.shortcuts import redirect
#.....................................
from .models import Producto
from .models import Cliente
# Create your views here.
#-------------------------------------------------------------------Mi formulario login
class LoginForm(forms.Form):
    username= forms.CharField(label=("Nombre de usuario"), required=True, widget=forms.TextInput(attrs={'size': '40'}))
    password= forms.CharField(widget=forms.PasswordInput,required=True,label=("Password"))
#--------------------------------------------------------------------------------------

def productos(request):
    productos = Producto.objects.all()
    return render(request,'cuerpo/productos.html',{'productos':productos})


def login(request):
    username = None
    form_login= LoginForm()
    if request.method == 'GET':
        if 'action' in request.GET:
            action =request.GET.get('action')
            if action == 'logout':
                if request.session.has_key('username'):
                    request.session.flush()
                #-------------Cuando quiere salir
                return redirect()

        if 'username' in request.session:
            username= request.session['username']
    elif request.method == 'POST':
        form_login= LoginForm(request.POST)
        if form_login.is_valid():
            username= form_login.cleaned_data['username']
            password= form_login.cleaned_data['password']
            #------------------------------------Validaciones login
            try:
                usuario = Cliente.objects.get(user=username)
                if(usuario.password != password):
                    messages.info(request, 'Informacion erronea')
                    #____________________Poner un alert o algo así
                else:
                    messages.info(request, 'Bienvenid@ ' + usuario.user)
                    request.session['username']=username
                    return render(request, 'cuerpo/index.html', {})
            except Cliente.DoesNotExist:
                messages.info(request, 'El usuario no esta registrado')
                username = None
                redirect('login')
    return render(request, 'cuerpo/iniciarSesión.html', {'form': form_login})















