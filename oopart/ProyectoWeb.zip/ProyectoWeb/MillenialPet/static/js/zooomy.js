$(function () {
    $('.zoom').zoomy();
});