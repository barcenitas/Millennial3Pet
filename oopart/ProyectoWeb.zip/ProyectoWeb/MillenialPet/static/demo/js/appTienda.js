
$(document).ready(function(){
  $('.modal').modal();
    $('.sidenav').sidenav();
 $('.tap-target').tapTarget();
  instance.next();

  });




